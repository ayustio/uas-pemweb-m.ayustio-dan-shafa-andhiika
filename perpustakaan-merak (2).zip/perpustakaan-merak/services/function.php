<?php
    function validasiDataRegistrasi($username, $password, $nama, $email) {
        if (preg_match("/^[a-zA-Z0-9]+$/", $username) == 0)
            return array("Username hanya boleh berisi huruf dan angka", false);
        
        if (preg_match("/^[a-zA-Z\s]+$/", $nama) == 0)
            return array("Nama hanya boleh berisi huruf", false);

        if (preg_match("/\s/", $password))
            return array("Peringatan Password mengandung spasi!", true);

        if (filter_var($email, FILTER_VALIDATE_EMAIL) == false)
            return array("Email tidak valid", false);

        return array("", true);
    }

    function addUser($username, $password, $nama, $email, $alamat, $no_telp, $gender, $role, $db) {
        $password = password_hash($password, PASSWORD_DEFAULT);
        
        $query = "INSERT INTO users (username, password, nama, email, alamat, nomor_telepon, jenis_kelamin, role) 
                  VALUES ('$username', '$password', '$nama', '$email', '$alamat', '$no_telp', '$gender', '$role')";
        
        try {
            $db->query($query);
        } catch (Exception $e) {
            echo "Failed to add user into database: " . $e->getMessage();
            die();
        }
    }

    function isUserExist($username, $db) {
        $query = "SELECT * FROM users WHERE username = '$username'";
        $result = $db->query($query);
        if ($result->num_rows > 0)
            return true;
        return false;
    }

    function getUser($username, $db) {
        $query = "SELECT * FROM users WHERE username = '$username'";
        $result = $db->query($query);
        if ($result->num_rows > 0)
            return $result->fetch_assoc();
    }

    function borrowBook($user_id, $book_id, $db) {
        $current_date = date("Y-m-d");
        $return_date = date("Y-m-d", strtotime($current_date . "+1 month"));

        $sql = "INSERT INTO di_pinjam (buku_id, user_id, tanggal_pinjaman, tanggal_pengembalian)
                VALUES ('$book_id', '$user_id', '$current_date', '$return_date')";

        if (validateBorrowBookByUser($user_id, $book_id, $db)) {
            return "Buku sudah dipinjam";
        }

        try {
            $db->query($sql);
            return "Buku berhasil dipinjam";
        } catch (Exception $e) {
            return "Gagal meminjam buku karena: " . $e->getMessage();
        }
    }

    function validateBorrowBookByUser($user_id, $book_id, $db) {
        $sql = "SELECT * FROM di_pinjam WHERE user_id = '$user_id' AND buku_id = '$book_id'";
        $result = $db->query($sql);

        if ($result->num_rows > 0) {
            return true;
        }
    }

    function validateBorrowBookByOther($book_id, $db) {
        $sql = "SELECT * FROM di_pinjam WHERE buku_id = '$book_id'";
        $result = $db->query($sql);

        if ($result->num_rows > 0) {
            return true;
        }
    }

    function returnBook($borrow_id, $db) {
        $sql = "DELETE FROM di_pinjam WHERE id = '$borrow_id'";

        try {
            $db->query($sql);
            return "Buku berhasil dikembalikan";
        } catch (Exception $e) {
            return "Gagal mengembalikan buku karena: " . $e->getMessage();
        }
    }

    function deleteBook($user_id, $book_id, $db) {
        $sql = "DELETE FROM daftar_buku WHERE id = '$book_id'";

        if (validateBorrowBookByUser($user_id, $book_id, $db)) {
            return "Buku sedang dipinjam, kembalikan terlebih dahulu";
        } else if (validateBorrowBookByOther($book_id, $db)) {
            return "Buku sedang dipinjam oleh user lain";
        }

        $file_path = "../images/" . getBookImage($book_id, $db);
        if (!file_exists($file_path)) {
            return "Gagal menghapus gambar buku";
        } else {
            unlink($file_path);
        }

        try {
            $db->query($sql);
            return "Buku berhasil dihapus";
        } catch (Exception $e) {
            return "Gagal menghapus buku karena: " . $e->getMessage();
        }
    }

    function getBookImage($book_id, $db) {
        $sql = "SELECT gambar FROM daftar_buku WHERE id = '$book_id'";
        $result = $db->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return $row['gambar'];
        }
    }
?>