<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            clifford: '#da373d',
            primary: '#FFFDEF',
            secondary: '#F1F1F1',
            tertiary: '#E70000',
            accent: '#C50000'
          }
        }
      }
    }
  </script>
    <title>Perpustakaan Merak</title>
</head>
<body>

    <div class="flex flex-col justify-center items-center h-screen">
        <div class="mt-auto w-1/2 shadow-lg rounded-lg bg-slate-50 max-w-96">
            <h1 class="bg-red-500 overflow-visible rounded-t-lg text-slate-50 text-center p-2 font-semibold">Selamat datang di Perpustakaan Merak</h1>
            <div class="flex flex-col p-4 space-y-3">
                <a href="login/" class="border rounded-md p-2 hover:bg-red-500 hover:text-slate-50 text-center font-medium">Masuk</a>
                <a href="daftar/" class="border rounded-md p-2 hover:bg-red-500 hover:text-slate-50 text-center font-medium">Daftar</a>
            </div>
        </div>
        <?php include "layouts/footer.html" ?>
    </div>
        
</body>
</html>