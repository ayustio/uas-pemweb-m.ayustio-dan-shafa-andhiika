<?php
if (!isset($user_profile)) {
    echo "<p>Profil pengguna tidak ditemukan.</p>";
    return;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
    <link rel="stylesheet" href="https://cdn.tailwindcss.com">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7fafc;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .profile-item {
            margin-bottom: 10px;
        }
        .profile-item label {
            font-weight: bold;
            display: block;
        }
        .profile-item p {
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-2xl font-semibold mb-4">Profil Pengguna</h2>
        <div class="profile-item">
            <label>Nama:</label>
            <p><?php echo htmlspecialchars($user_profile['nama']); ?></p>
        </div>
        <div class="profile-item">
            <label>Email:</label>
            <p><?php echo htmlspecialchars($user_profile['email']); ?></p>
        </div>
        <div class="profile-item">
            <label>Telepon:</label>
            <p><?php echo htmlspecialchars($user_profile['nomor_telepon']); ?></p>
        </div>
        <div class="profile-item">
            <label>Alamat:</label>
            <p><?php echo htmlspecialchars($user_profile['alamat']); ?></p>
        </div>
    </div>
</body>
</html>
