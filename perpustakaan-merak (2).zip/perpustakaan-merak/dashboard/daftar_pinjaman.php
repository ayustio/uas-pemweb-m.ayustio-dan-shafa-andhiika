<?php
    $sql = "SELECT daftar_buku.gambar, di_pinjam.id as borrow_id, daftar_buku.id, daftar_buku.nama, di_pinjam.tanggal_pinjaman, di_pinjam.tanggal_pengembalian
            FROM di_pinjam
            JOIN users ON di_pinjam.user_id = users.id
            JOIN daftar_buku ON di_pinjam.buku_id = daftar_buku.id
            WHERE users.username = '".$_SESSION['username']."'";
    $result = $db->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2 class='font-medium text-center p-4'>Daftar Buku yang di Pinjam</h2>";
        echo "<hr class='border-x-2 border-slate-500'>";
        echo "<div class='max-h-[70vh] overflow-y-scroll'>";
        echo "<table class='table-auto border-collapse border border-gray-800 w-full'>
                <thead>
                    <tr>
                        <th class='border-b border-t border-gray-600'>No Buku</th>
                        <th class='border-b border-t border-gray-600'>Cover</th>
                        <th class='border-b border-t border-gray-600'>Judul Buku</th>
                        <th class='border-b border-t border-gray-600'>Tanggal Peminjaman</th>
                        <th class='border-b border-t border-gray-600'>Tanggal Pengembalian</th>
                        <th class='border-b border-t border-gray-600'>Opsi</th>
                    </tr>
                </thead>
                <tbody>";
        while($row = $result->fetch_assoc()) {
            echo "
                <tr>
                    <td class='border border-gray-400'>".$row["id"]."</td>
                    <td class='border border-gray-400'><img style='max-height: 240px; max-width: 240px;' src='../images/".$row["gambar"]."'></td>
                    <td class='border border-gray-400'>".$row["nama"]."</td>
                    <td class='border border-gray-400'>".$row["tanggal_pinjaman"]."</td>
                    <td class='border border-gray-400'>".$row["tanggal_pengembalian"]."</td>
                    <td class='border border-gray-400 text-center'>
                        <form action='../dashboard/' method='POST'>
                            <input type='hidden' name='kembalikan' value='".$row['borrow_id']."'>
                            <button class='bg-red-500 py-1 px-3 rounded-md hover:bg-red-700 font-medium text-slate-50' type='submit' name='kembalikan_buku'>Return</button>
                        </form>
                    </td>
                </tr>";
        }
        echo "  </tbody>
            </table>";
        echo "</div>";
    } else {
        echo "<h2 class='font-medium text-center p-4'>Daftar Buku yang di Pinjam</h2>";
        echo "<hr class='border-x-2 border-slate-500'>";
        echo "<div class='flex flex-col justify-center h-screen max-h-[70vh]'>";
        echo "<p class='text-center my-auto'>".$_SESSION['nama']." belum meminjam buku</p>";
        echo "</div>";
    }

    $db->close();
?>