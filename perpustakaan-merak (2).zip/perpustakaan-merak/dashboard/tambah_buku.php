<h2 class="font-medium text-center p-4">Form Penambahan Buku ke dalam Database</h2>
<hr class="border-x-2 border-slate-500">
<form class="flex flex-col" action="../dashboard/" method="POST" enctype="multipart/form-data">
    <label class="p-2 font-medium" for="judul">Judul Buku</label>
    <input class="p-2 bg-gray-100" type="text" name="judul" required>
    <label class="p-2 font-medium" for="penulis">Penulis</label>
    <input class="p-2 bg-gray-100" type="text" name="penulis" required>
    <label class="p-2 font-medium" for="penerbit">Penerbit</label>
    <input class="p-2 bg-gray-100" type="text" name="penerbit" required>
    <label class="p-2 font-medium" for="tahun">Tahun Terbit</label>
    <input class="p-2 bg-gray-100" type="date" name="tahun_terbit" required>
    <label class="p-2 font-medium" for="kategori">Kategori</label>
        <select class="p-2 bg-gray-100" name="kategori" required>
            <option value="Novel">Novel</option>
            <option value="Komik">Komik</option>
            <option value="Biografi">Biografi</option>
            <option value="Ensiklopedia">Ensiklopedia</option>
            <option value="Lainnya">Lainnya</option>
        </select>
    <label class="p-2 font-medium" for="deskripsi">Deskripsi</label>
    <textarea class="p-2 bg-gray-100 resize-none" name="deskripsi"></textarea>
    <label class="p-2 font-medium" for="gambar">Cover</label>
    <input type="file" name="gambar">
    <button class="bg-red-500 text-slate-50 hover:bg-red-700 rounded-md w-1/3 p-1.5 self-center font-medium text-center mt-3.5 type="submit" name="tambah_buku">Tambah Buku</button>
</form>