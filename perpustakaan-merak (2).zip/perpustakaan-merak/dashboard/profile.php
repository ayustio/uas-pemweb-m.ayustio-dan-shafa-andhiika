<?php
include "../services/database.php";
include "../services/function.php";

session_start();

if (!isset($_SESSION['is_login'])) {
    header("Location: ../login");
    exit;
}

function getUserProfile($user_id, $db) {
    $sql = "SELECT * FROM users WHERE id = $user_id";
    $result = $db->query($sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

$user_profile = getUserProfile($_SESSION['user_id'], $db);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profil Pengguna</title>
</head>
<body>
    <h2>Profil Pengguna</h2>
    <?php if ($user_profile): ?>
        <p><strong>Nama:</strong> <?php echo htmlspecialchars($user_profile['nama']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user_profile['email']); ?></p>
        <p><strong>Telepon:</strong> <?php echo htmlspecialchars($user_profile['nomor_telepon']); ?></p>
        <p><strong>Alamat:</strong> <?php echo htmlspecialchars($user_profile['alamat']); ?></p>
    <?php else: ?>
        <p>Profil pengguna tidak ditemukan.</p>
    <?php endif; ?>
</body>
</html>
