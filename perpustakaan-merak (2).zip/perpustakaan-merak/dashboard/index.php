<?php
include "../services/database.php";
session_start();

$tambah_buku_result = "";
$pinjam_buku_result = "";
$return_buku_result = "";
$hapus_buku_result = "";

if (!isset($_SESSION['profile_update'])) {
    $_SESSION['profile_update'] = "";
}

if (!isset($_SESSION['is_login'])) {
    header("Location: ../login");
    exit;
}

if (isset($_POST['keluar'])) {
    session_unset();
    session_destroy();
    header("Location: ../");
    exit;
}

if (isset($_POST['tambah_buku'])) {
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $kategori = $_POST['kategori'];
    $deskripsi = $_POST['deskripsi'];
    $gambar = $_FILES['gambar']['name'];
    $tmp_name = $_FILES['gambar']['tmp_name'];
    $folder = "../images/".$gambar;

    $sql = "INSERT INTO daftar_buku (nama, penulis, penerbit, tahun_terbit, kategori, deskripsi, gambar) 
            VALUES ('$judul', '$penulis', '$penerbit', '$tahun_terbit', '$kategori', '$deskripsi', '$gambar')";

    $tambah_buku_result = $db->query($sql);
    $tambah_buku_result = "Buku berhasil ditambahkan";

    if (!move_uploaded_file($tmp_name, $folder)) {
        $tambah_buku_result = "Gagal mengunggah gambar";
    }
}

if (isset($_POST['pinjam_buku'])) {
    $id = $_POST['pinjam'];
    $pinjam_buku_result = borrowBook($_SESSION['user_id'], $id, $db);
}

if (isset($_POST['kembalikan_buku'])) {
    $borrow_id = $_POST['kembalikan'];
    $return_buku_result = returnBook($borrow_id, $db);
}

if (isset($_POST['hapus_buku'])) {
    $book_id = $_POST['hapus'];
    $hapus_buku_result = deleteBook($_SESSION['user_id'], $book_id, $db);
}

// Get user profile
function getUserProfile($user_id, $db) {
    $sql = "SELECT * FROM users WHERE id = $user_id";
    $result = $db->query($sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

$user_profile = getUserProfile($_SESSION['user_id'], $db);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            clifford: '#da373d',
            primary: '#FFFDEF',
            secondary: '#F1F1F1',
            tertiary: '#E70000',
            accent: '#C50000'
          }
        }
      }
    }
    </script>
    <title>Dashboard</title>
</head>
<body>
    <div class="flex flex-col justify-center items-center h-screen">
        <div class="w-screen bg-red-500">
            <h2 class="text-slate-50 text-center font-semibold p-3 text-2xl">Selamat datang <?php echo $_SESSION['nama'] ?>!</h2>

            <form class="flex justify-center space-x-3 pb-4" action="index.php" method="post">
                <button class="w-auto px-3 py-1 rounded-md bg-white shadow-md hover:bg-slate-200" type="submit" name="daftar_pinjaman">Daftar Pinjaman</button>
                <button class="w-auto px-3 py-1 rounded-md bg-white shadow-md hover:bg-slate-200" type="submit" name="daftar_buku">Daftar Buku</button>
                <button class="w-auto px-3 py-1 rounded-md bg-white shadow-md hover:bg-slate-200" type="submit" name="view_profile">Profil</button>
                <?php
                    if ($_SESSION['role'] == 'admin') {
                        echo '<button class="w-auto px-3 py-1 rounded-md bg-white shadow-md hover:bg-slate-200" type="submit" name="form_tambah_buku">Tambah Buku</button>';
                    }
                ?>
                <button class="w-auto px-3 py-1 rounded-md bg-white shadow-md hover:bg-slate-200" type="submit" name="keluar">Keluar</button>
            </form>
        </div>

        <div class="flex flex-col w-4/5">
            <?php 
                if (isset($_POST['daftar_pinjaman']) || isset($_POST['kembalikan_buku'])) {
                    include "daftar_pinjaman.php";
                    echo "<p class='text-center'>$return_buku_result</p>";
                }

                if (isset($_POST['daftar_buku']) || isset($_POST['pinjam_buku']) || isset($_POST['hapus_buku'])) {
                    include "daftar_buku.php";
                    echo "<p class='text-center mt-4'>$pinjam_buku_result</p>";
                    echo "<p class='text-center'>$hapus_buku_result</p>";
                }

                if (isset($_POST['form_tambah_buku']) || isset($_POST['tambah_buku'])) {
                    include "tambah_buku.php";
                    echo "<p class='text-center mt-4'>$tambah_buku_result</p>";
                }

                if (isset($_POST['view_profile'])) {
                    include "profile_view.php";
                }
            ?>
        </div>

        <?php include "../layouts/footer.html" ?>
    </div>
</body>
</html>
