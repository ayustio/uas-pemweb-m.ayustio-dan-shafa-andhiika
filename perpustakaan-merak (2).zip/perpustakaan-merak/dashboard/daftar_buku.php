<?php
    $sql = "SELECT * FROM daftar_buku";
    $result = $db->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2 class='font-medium text-center p-4'>Daftar Buku di Perpustakaan</h2>";
        echo "<hr class='border-x-2 border-slate-500'>";
        echo "<div class='flex flex-col overflow-y-scroll overflow-x-scroll max-h-[70vh]'>";
        
        while ($row = $result->fetch_assoc()) {
            echo    "<div class='max-w-full min-w-full min-h-[23rem] max-h-[23rem] flex border border-gray-500'>
                        <div class='min-w-[187px] max-w-[187px] flex flex-col border-r border-gray-500'>
                            <img class='h-full w-full object-contain' src='../images/".$row['gambar']."' alt='../images/no-cover.gif'>
                            <p class='text-center p-4 overflow-clip'>".$row['nama']."</p>
                        </div>
                        <div class='flex flex-col'>
                            <div class='w-full p-3.5'>
                                <p>Nomor Buku: ".$row['id']."</p>
                            </div>
                            <div class='w-full h-full p-3.5 border-y border-gray-500'>
                                <p>".$row['deskripsi']."</p>
                            </div>
                            <div class='flex'>
                                <div class='p-4 w-44 border-r border-gray-500'>
                                    <p>Penulis: ".$row['penulis']."</p>
                                </div>
                                <div class='p-4 w-44 border-r border-gray-500'>
                                    <p>Penerbit: ".$row['penerbit']."</p>
                                </div>
                                <div class='p-4 w-44 border-r border-gray-500'>
                                    <p>Tahun terbit: ".$row['tahun_terbit']."</p>
                                </div>
                                <div class='p-4 w-44'>
                                    <p>Kategori: ".$row['kategori']."</p>
                                </div>
                            </div>
                        </div>";
                        if ($_SESSION['role'] == 'admin') {
                            echo 
                            "
                            <div class='flex flex-col py-4 px-4 border-l border-gray-500 justify-around'>
                                <form action='../dashboard/' method='POST'>
                                    <input type='hidden' name='pinjam' value='".$row['id']."'>
                                    <button class='bg-red-500 py-1 px-3 rounded-md hover:bg-red-700 font-medium text-slate-50' type='submit' name='pinjam_buku'>Pinjam</button>
                                </form>
                                <form action='../dashboard/' method='POST'>
                                    <input type='hidden' name='hapus' value='".$row['id']."'>
                                    <button class='bg-red-500 py-1 px-3 rounded-md hover:bg-red-700 font-medium text-slate-50' type='submit' name='hapus_buku'>Hapus</button>
                                </form>
                            </div>
                            ";
                        } else {
                            echo 
                            "
                            <div class='flex flex-col py-4 px-4 border-l border-gray-500 justify-around'>
                                <form action='../dashboard/' method='POST'>
                                    <input type='hidden' name='pinjam' value='".$row['id']."'>
                                    <button class='bg-red-500 py-1 px-3 rounded-md hover:bg-red-700 font-medium text-slate-50' type='submit' name='pinjam_buku'>Pinjam</button>
                                </form>
                            </div>
                            ";
                        }
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<h2 class='font-medium text-center p-4'>Daftar Buku di Perpustakaan</h2>";
        echo "<hr class='border-x-2 border-slate-500'>";
        echo "<div class='flex flex-col justify-center h-screen max-h-[70vh]'>";
        echo "<p class='text-center my-auto'>Tidak ada buku di perpustakaan.</p>";
        echo "</div>";
    }

    $db->close();
?>

