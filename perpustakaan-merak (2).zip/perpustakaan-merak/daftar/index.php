<?php
    include "../services/database.php";
    include "../services/function.php";

    $result = "Isi form berikut untuk mendaftar";
    $result_flag = false;

    if (isset($_POST['daftar'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $nama_depan = $_POST['nama_depan'];
        $nama_belakang = $_POST['nama_belakang'];
        $nama = $nama_depan . " " . $nama_belakang;
        $email = $_POST['email'];
        $alamat = $_POST['alamat'];
        $no_telp = $_POST['no_telp'];
        $gender = $_POST['gender'];
        $role = "user";

        list($result, $result_flag) = validasiDataRegistrasi($username, $password, $nama, $email);
        
        if ($result_flag === true) {
            if (isUserExist($username, $db)) {
                $result = "Username sudah digunakan!";
            } else {
                addUser($username, $password, $nama, $email, $alamat, $no_telp, $gender, $role, $db);
                if ($result == "")
                    $result = "User berhasil didaftarkan!";
            }
        }

        $db->close();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            clifford: '#da373d',
            primary: '#FFFDEF',
            secondary: '#F1F1F1',
            tertiary: '#E70000',
            accent: '#C50000'
          }
        }
      }
    }
    </script>
    <title>Perpustakaan Merak</title>
</head>
<body>
    <div class="flex flex-col justify-center items-center h-screen">
        <div class="mt-auto w-1/2 shadow-lg rounded-lg bg-slate-50 max-w-96">
            <h2 class="bg-red-500 overflow-visible rounded-t-lg text-slate-50 text-center p-2 font-semibold"><i class="fa-solid fa-user pr-1"></i>Daftar</h2>
        
            <div class="flex flex-col p-4">
                <p class="text-center"><?php echo $result; ?></p>
        
                <form class="flex flex-col space-y-2" action="index.php" method="post">
                        <input class="text-center border rounded-md focus:outline-none focus:ring-1 focus:ring-slate-300 mt-3.5" type="text" name="username" placeholder="Username" required maxlength="255">
                        <input class="text-center border rounded-md focus:outline-none focus:ring-1 focus:ring-slate-300" type="password" name="password" placeholder="Password" required maxlength="255">
                        <div class="flex justify-around">
                            <input class="w-1/2 text-center border rounded-md focus:outline-none focus:ring-1 focus:ring-slate-300" type="text" name="nama_depan" placeholder="Nama Depan" required maxlength="255">
                            <input class="w-1/2 text-center border rounded-md focus:outline-none focus:ring-1 focus:ring-slate-300" type="text" name="nama_belakang" placeholder="Nama Belakang" maxlength="255">
                        </div>
                        <input class="text-center border rounded-md focus:outline-none focus:ring-1 focus:ring-slate-300" type="email" name="email" placeholder="E-Mail" required maxlength="255">
                        <input class="text-center border rounded-md focus:outline-none focus:ring-1 focus:ring-slate-300" type="text" name="alamat" placeholder="Alamat" maxlength="255">
                        <input class="text-center border rounded-md focus:outline-none focus:ring-1 focus:ring-slate-300" type="text" name="no_telp" placeholder="Nomor Telepon" maxlength="255">
                        <label class="text-center" for="gender">Jenis Kelamin</label>
                        <div class="flex justify-around">
                            <div class="flex flex-col">
                                <label for="gender">Laki-laki</label>
                                <input type="radio" name="gender" value="Laki-laki" required>
                            </div>
                            <div class="flex flex-col">
                                <label for="gender">Perempuan</label>
                                <input type="radio" name="gender" value="Perempuan" required>
                            </div>
                        </div>
                        <button class="justify-center bg-red-500 text-slate-50 hover:bg-red-700 rounded-md w-1/3 p-1.5 self-center font-medium text-center mt-3.5" type="submit" name="daftar">Daftar</button>
                </form>
                
                
                <p class="mt-3">Sudah punya akun? <a class="font-medium hover:text-red-500 underline" href="../login/">Masuk</a></p>
            </div>
        </div>
    
        <?php include "../layouts/footer.html"?>
    </div>
</body>
</html>