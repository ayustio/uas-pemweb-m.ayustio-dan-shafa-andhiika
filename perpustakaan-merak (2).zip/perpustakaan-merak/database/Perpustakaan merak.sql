-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 07 Jun 2024 pada 08.35
-- Versi server: 8.0.30
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan_merak`
--
CREATE DATABASE IF NOT EXISTS `perpustakaan_merak` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `perpustakaan_merak`;

-- --------------------------------------------------------

CREATE TABLE user_profiles (
    user_id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(15),
    address TEXT
);



--
-- Struktur dari tabel `daftar_buku`
--

CREATE TABLE `daftar_buku` (
  `id` int NOT NULL,
  `nama` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `penerbit` varchar(255) NOT NULL,
  `tahun_terbit` date NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `deskripsi` varchar(1000) NOT NULL,
  `gambar` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `di_pinjam`
--

CREATE TABLE `di_pinjam` (
  `id` int NOT NULL,
  `buku_id` int NOT NULL,
  `user_id` int NOT NULL,
  `tanggal_pinjaman` date NOT NULL,
  `tanggal_pengembalian` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `nomor_telepon` varchar(255) DEFAULT NULL,
  `jenis_kelamin` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `nama`, `email`, `alamat`, `nomor_telepon`, `jenis_kelamin`, `role`) VALUES
(2, 'admin', '$2y$10$Q7Sp2f41hLxLt4VkIgFohumvOCzjmiZ168uDQsbySVzhXJ.NbrZlG', 'Admin Satu', 'admin@admin.com', '', '', 'Laki-laki', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `daftar_buku`
--
ALTER TABLE `daftar_buku`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `di_pinjam`
--
ALTER TABLE `di_pinjam`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `buku_id` (`buku_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `daftar_buku`
--
ALTER TABLE `daftar_buku`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `di_pinjam`
--
ALTER TABLE `di_pinjam`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `di_pinjam`
--
ALTER TABLE `di_pinjam`
  ADD CONSTRAINT `di_pinjam_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `di_pinjam_ibfk_2` FOREIGN KEY (`buku_id`) REFERENCES `daftar_buku` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;






-- create data
INSERT INTO user_profiles (user_id, name, email, phone, address) VALUES (1, 'Nama Pengguna', 'email@example.com', '08123456789', 'Alamat Lengkap');




INSERT INTO user_profiles (user_id, name, email, phone, address) VALUES (3, 'Imam', 'imamariadi@gmail.com', '08123456789', 'Alamat Lengkap');



INSERT INTO daftar_buku (nama, deskripsi, penulis, penerbit, tahun_terbit, kategori, gambar) VALUES
('Belajar PHP', 'Buku panduan lengkap untuk belajar pemrograman PHP.', 'Ahmad Fauzi', 'Penerbit Teknologi', '2021', 'Pemrograman', 'belajar_php.jpg'),
('Misteri di Balik Gunung', 'Novel misteri tentang petualangan di gunung berapi.', 'Dewi Lestari', 'Penerbit Sastra', '2020', 'Fiksi', 'misteri_gunung.jpg'),
('Sejarah Nusantara', 'Buku sejarah yang menjelaskan perjalanan panjang nusantara.', 'Budi Setiawan', 'Penerbit Sejarah', '2018', 'Sejarah', 'sejarah_nusantara.jpg'),
('Panduan Bisnis Online', 'Strategi dan tips sukses menjalankan bisnis online.', 'Rina Kartika', 'Penerbit Bisnis', '2019', 'Bisnis', 'bisnis_online.jpg'),
('Rahasia Kesehatan Alami', 'Panduan menjaga kesehatan dengan cara alami.', 'Dr. Arif Budiman', 'Penerbit Kesehatan', '2022', 'Kesehatan', 'kesehatan_alami.jpg'),
('Memasak dengan Cinta', 'Kumpulan resep masakan dengan cita rasa tinggi.', 'Chef Tyo', 'Penerbit Kuliner', '2021', 'Kuliner', 'memasak_cinta.jpg'),
('Petualangan si Kancil', 'Cerita anak-anak tentang kecerdikan si Kancil.', 'Ayu Wulandari', 'Penerbit Anak', '2020', 'Anak-anak', 'petualangan_kancil.jpg'),
('Fotografi Dasar', 'Buku panduan dasar fotografi untuk pemula.', 'Dian Pratama', 'Penerbit Seni', '2023', 'Fotografi', 'fotografi_dasar.jpg'),
('Teknologi Masa Depan', 'Prediksi tentang teknologi yang akan datang.', 'Yusuf Maulana', 'Penerbit Sains', '2024', 'Teknologi', 'teknologi_masa_depan.jpg'),
('Kisah Inspiratif', 'Kumpulan kisah inspiratif dari tokoh-tokoh terkenal.', 'Linda Anggraeni', 'Penerbit Motivasi', '2022', 'Motivasi', 'kisah_inspiratif.jpg');
