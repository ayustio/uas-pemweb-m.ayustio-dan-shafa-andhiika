<?php
    include "../services/database.php";
    include "../services/function.php";
    session_start();

    $result = "Masukkan username dan password";

    if (isset($_POST['masuk'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if (isUserExist($username, $db)) {
            $user = getUser($username, $db);
            if (password_verify($password, $user['password'])) {
                $result = "Berhasil masuk!";
                $_SESSION['is_login'] = true;
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['nama'] = $user['nama'];
                $_SESSION['user_id'] = $user['id'];
                header("Location: ../dashboard/");
            } else {
                $result = "Username atau password salah!";
            }
        } else {
            $result = "Username atau password salah!";
        }
        $db->close();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            clifford: '#da373d',
            primary: '#FFFDEF',
            secondary: '#F1F1F1',
            tertiary: '#E70000',
            accent: '#C50000'
          }
        }
      }
    }
    </script>
    <title>Perpustakaan Merak</title>
</head>
<body>

    <div class="flex flex-col justify-center items-center h-screen">
        <div class="mt-auto w-1/2 shadow-lg rounded-lg bg-slate-50 max-w-96">
            <h2 class="bg-red-500 overflow-visible rounded-t-lg text-slate-50 text-center p-2 font-semibold"><i class="fa-solid fa-user pr-1"></i>Masuk</h2>
        
            <div class="flex flex-col p-4">
                <p class="text-center"><?php echo $result; ?></np>
                
                <form class="flex flex-col" action="index.php" method="post">
                    <input class="text-center border rounded-md focus:outline-none focus:ring-1 focus:ring-slate-300 mt-3.5" type="text" name="username" placeholder="Username" required>
                    <input class="text-center border rounded-md focus:outline-none focus:ring-1 focus:ring-slate-300 mt-2" type="password" name="password" placeholder="Password" required>
                    <button class="bg-red-500 text-slate-50 hover:bg-red-700 rounded-md w-1/3 p-1.5 self-center font-medium text-center mt-3.5" type="submit" name="masuk">Masuk</button>
                </form>
            
                <p class="mt-2">Belum punya akun? <a class="font-medium hover:text-red-500 underline" href="../daftar/">Daftar</a></p>
            </div>
        </div>
    
        <?php include "../layouts/footer.html"?>
    </div>
</body>
</html>